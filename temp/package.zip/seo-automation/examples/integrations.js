/**
 * SEO Automation Integration Examples
 * 
 * Examples showing how to integrate SEO automation with different frameworks
 * 
 * Author: MiniMax Agent
 * Version: 1.0.0
 */

// Example 1: Basic integration with Node.js
class BasicIntegration {
    constructor() {
        this.seo = null;
    }

    async initialize() {
        const SEOAutomationSuite = require('../lib/seo-automation');
        this.seo = new SEOAutomationSuite('./config/seo-config.json');
        await this.seo.initialize();
    }

    async runAudit() {
        if (!this.seo) await this.initialize();
        
        const results = await this.seo.runFullAudit();
        
        // Process results
        console.log(`SEO Score: ${results.summary.score}/100`);
        
        // Send alerts if score is low
        if (results.summary.score < 70) {
            await this.sendSEOAlert(results);
        }
        
        return results;
    }

    async sendSEOAlert(results) {
        // Implementation for sending alerts (Slack, email, etc.)
        console.log(`🚨 SEO Alert: Score dropped to ${results.summary.score}/100`);
    }
}

// Example 2: React/Next.js integration
class ReactIntegration {
    constructor() {
        this.isServerSide = typeof window === 'undefined';
    }

    // Use in getServerSideProps or API routes
    async getSEOMetrics(siteUrl) {
        if (!this.isServerSide) return null;

        try {
            const SEOAutomationSuite = require('../lib/seo-automation');
            const seo = new SEOAutomationSuite('./config/seo-config.json');
            await seo.initialize();

            const results = await seo.runFullAudit({
                maxPages: 5, // Limit for server-side rendering
                quickMode: true
            });

            return {
                seoScore: results.summary.score,
                technicalIssues: results.audit.technical?.issues.length || 0,
                performanceScore: results.audit.performance?.score || 0,
                contentScore: results.audit.content?.score || 0
            };
        } catch (error) {
            console.error('SEO analysis failed:', error);
            return null;
        }
    }

    // Add SEO meta tags dynamically
    generateSEOMetaTags(analysisResults) {
        if (!analysisResults) return {};

        const { seoScore, technicalIssues } = analysisResults;
        
        return {
            title: seoScore >= 80 ? 'High Quality SEO Website' : 'Website SEO Analysis',
            description: `SEO Analysis: Score ${seoScore}/100. ${technicalIssues} issues found.`,
            'og:title': 'SEO Optimized Website',
            'og:description': `Comprehensive SEO analysis with score ${seoScore}/100`,
            'twitter:card': 'summary_large_image'
        };
    }
}

// Example 3: Vue.js/Nuxt.js integration
class VueIntegration {
    constructor() {
        this.seoPlugin = null;
    }

    // Nuxt.js plugin example
    createSEOPlugin() {
        return {
            name: 'seo-plugin',
            
            async generate(siteUrl) {
                const results = await this.runQuickAudit(siteUrl);
                
                return {
                    // Generate meta tags
                    head: {
                        title: this.generateSEOTitle(results),
                        meta: this.generateSEOMeta(results)
                    }
                };
            },

            async runQuickAudit(siteUrl) {
                const SEOAutomationSuite = require('../lib/seo-automation');
                const seo = new SEOAutomationSuite('./config/seo-config.json');
                await seo.initialize();
                
                return await seo.runFullAudit({
                    maxPages: 3,
                    quickMode: true
                });
            },

            generateSEOTitle(results) {
                const score = results.summary.score;
                if (score >= 90) return 'Excellent SEO - Premium Website';
                if (score >= 80) return 'Good SEO Optimized Website';
                if (score >= 70) return 'SEO Analysis Results';
                return 'SEO Issues Found - Needs Optimization';
            },

            generateSEOMeta(results) {
                return [
                    { charset: 'utf-8' },
                    { name: 'viewport', content: 'width=device-width, initial-scale=1' },
                    { name: 'description', content: `SEO Score: ${results.summary.score}/100` },
                    // Add more meta tags based on analysis
                ];
            }
        };
    }
}

// Example 4: WordPress integration (via REST API)
class WordPressIntegration {
    constructor(siteUrl, apiKey = null) {
        this.siteUrl = siteUrl;
        this.apiKey = apiKey;
        this.baseUrl = `${siteUrl}/wp-json/wp/v2`;
    }

    async analyzeWordPressSEO() {
        try {
            // Check for popular SEO plugins
            const plugins = await this.getPlugins();
            const hasYoast = plugins.some(p => p.name.includes('Yoast SEO'));
            const hasRankMath = plugins.some(p => p.name.includes('Rank Math'));

            // Get posts and analyze SEO
            const posts = await this.getPosts();
            const analysis = await this.analyzePosts(posts);

            // Generate recommendations
            const recommendations = await this.generateWordPressRecommendations(
                analysis, 
                { hasYoast, hasRankMath }
            );

            return {
                pluginAnalysis: { hasYoast, hasRankMath },
                contentAnalysis: analysis,
                recommendations
            };

        } catch (error) {
            throw new Error(`WordPress SEO analysis failed: ${error.message}`);
        }
    }

    async getPlugins() {
        if (!this.apiKey) return [];
        
        const response = await fetch(`${this.baseUrl}/plugins`, {
            headers: {
                'Authorization': `Bearer ${this.apiKey}`
            }
        });
        
        return response.json();
    }

    async getPosts() {
        if (!this.apiKey) return [];
        
        const response = await fetch(`${this.baseUrl}/posts?per_page=10`, {
            headers: {
                'Authorization': `Bearer ${this.apiKey}`
            }
        });
        
        return response.json();
    }

    async analyzePosts(posts) {
        const analysis = {
            totalPosts: posts.length,
            seoOptimizedPosts: 0,
            averageWordCount: 0,
            missingMetaDescriptions: 0,
            keywordOptimization: {}
        };

        let totalWords = 0;

        posts.forEach(post => {
            // Check if post has SEO meta
            const hasSEOMeta = post.yoast_meta || post.rank_math_meta;
            
            if (hasSEOMeta) {
                analysis.seoOptimizedPosts++;
            }

            // Count words in content
            const wordCount = post.content.rendered.split(/\s+/).length;
            totalWords += wordCount;

            // Check meta description
            const metaDescription = post.excerpt.rendered.replace(/<[^>]*>/g, '').trim();
            if (metaDescription.length < 120) {
                analysis.missingMetaDescriptions++;
            }
        });

        analysis.averageWordCount = Math.round(totalWords / posts.length);

        return analysis;
    }

    async generateWordPressRecommendations(analysis, plugins) {
        const recommendations = [];

        if (analysis.averageWordCount < 300) {
            recommendations.push({
                type: 'content_length',
                priority: 'high',
                message: `Average content length is ${analysis.averageWordCount} words. Consider increasing to 1000+ words for better SEO.`
            });
        }

        if (analysis.missingMetaDescriptions > analysis.totalPosts * 0.5) {
            recommendations.push({
                type: 'meta_descriptions',
                priority: 'medium',
                message: 'Many posts missing optimized meta descriptions.'
            });
        }

        if (!plugins.hasYoast && !plugins.hasRankMath) {
            recommendations.push({
                type: 'seo_plugin',
                priority: 'high',
                message: 'Install an SEO plugin (Yoast SEO or Rank Math) for better optimization.'
            });
        }

        return recommendations;
    }
}

// Example 5: Shopify integration
class ShopifyIntegration {
    constructor(shopifyStore, accessToken) {
        this.shopifyStore = shopifyStore;
        this.accessToken = accessToken;
        this.apiUrl = `https://${shopifyStore}.myshopify.com/admin/api/2023-10`;
    }

    async analyzeShopifySEO() {
        try {
            const products = await this.getProducts();
            const pages = await this.getPages();
            
            const productAnalysis = await this.analyzeProducts(products);
            const pageAnalysis = await this.analyzePages(pages);

            return {
                productSEO: productAnalysis,
                pageSEO: pageAnalysis,
                recommendations: this.generateShopifyRecommendations(productAnalysis, pageAnalysis)
            };

        } catch (error) {
            throw new Error(`Shopify SEO analysis failed: ${error.message}`);
        }
    }

    async getProducts() {
        const response = await fetch(`${this.apiUrl}/products.json`, {
            headers: {
                'X-Shopify-Access-Token': this.accessToken
            }
        });
        
        const data = await response.json();
        return data.products || [];
    }

    async getPages() {
        const response = await fetch(`${this.apiUrl}/pages.json`, {
            headers: {
                'X-Shopify-Access-Token': this.accessToken
            }
        });
        
        const data = await response.json();
        return data.pages || [];
    }

    async analyzeProducts(products) {
        const analysis = {
            totalProducts: products.length,
            productsWithSEO: 0,
            productsWithImages: 0,
            averageTitleLength: 0,
            averageDescriptionLength: 0
        };

        let totalTitleLength = 0;
        let totalDescriptionLength = 0;

        products.forEach(product => {
            // Check if product has SEO title and description
            if (product.meta_title || product.meta_description) {
                analysis.productsWithSEO++;
            }

            // Check if product has images
            if (product.images && product.images.length > 0) {
                analysis.productsWithImages++;
            }

            // Analyze title and description lengths
            const titleLength = product.title ? product.title.length : 0;
            const descriptionLength = product.body_html ? 
                product.body_html.replace(/<[^>]*>/g, '').length : 0;
            
            totalTitleLength += titleLength;
            totalDescriptionLength += descriptionLength;
        });

        analysis.averageTitleLength = Math.round(totalTitleLength / products.length);
        analysis.averageDescriptionLength = Math.round(totalDescriptionLength / products.length);

        return analysis;
    }

    async analyzePages(pages) {
        const analysis = {
            totalPages: pages.length,
            pagesWithSEO: 0,
            averageWordCount: 0
        };

        let totalWordCount = 0;

        pages.forEach(page => {
            if (page.meta_title || page.meta_description) {
                analysis.pagesWithSEO++;
            }

            const wordCount = page.body ? page.body.split(/\s+/).length : 0;
            totalWordCount += wordCount;
        });

        analysis.averageWordCount = Math.round(totalWordCount / pages.length);

        return analysis;
    }

    generateShopifyRecommendations(productAnalysis, pageAnalysis) {
        const recommendations = [];

        if (productAnalysis.productsWithSEO < productAnalysis.totalProducts * 0.8) {
            recommendations.push({
                type: 'product_seo',
                priority: 'high',
                message: 'Optimize SEO titles and descriptions for products.'
            });
        }

        if (productAnalysis.averageTitleLength < 30) {
            recommendations.push({
                type: 'product_titles',
                priority: 'medium',
                message: 'Product titles are too short. Aim for 30-60 characters.'
            });
        }

        if (pageAnalysis.pagesWithSEO < pageAnalysis.totalPages) {
            recommendations.push({
                type: 'page_seo',
                priority: 'high',
                message: 'Add SEO meta tags to all pages.'
            });
        }

        return recommendations;
    }
}

// Example 6: Continuous Integration setup
class CIIntegration {
    constructor() {
        this.seoThresholds = {
            critical: 50,
            warning: 70,
            good: 80
        };
    }

    async runCISEOAudit(config = {}) {
        const SEOAutomationSuite = require('../lib/seo-automation');
        const seo = new SEOAutomationSuite(config.configPath || './config/seo-config.json');
        
        await seo.initialize();

        const results = await seo.runFullAudit({
            maxPages: config.maxPages || 20,
            quickMode: true
        });

        const score = results.summary.score;
        const status = this.getCIStatus(score);

        // Generate CI report
        const report = {
            status,
            score,
            threshold: this.seoThresholds,
            issues: results.summary.issues,
            recommendations: results.summary.recommendations
        };

        // Output for CI systems
        this.outputCIResults(report);

        // Fail build if critical
        if (status === 'critical') {
            throw new Error(`SEO Score ${score} below critical threshold ${this.seoThresholds.critical}`);
        }

        return report;
    }

    getCIStatus(score) {
        if (score < this.seoThresholds.critical) return 'critical';
        if (score < this.seoThresholds.warning) return 'warning';
        if (score < this.seoThresholds.good) return 'needs_improvement';
        return 'good';
    }

    outputCIResults(report) {
        // GitHub Actions format
        console.log(`::notice::SEO Audit Score: ${report.score}/100`);
        
        if (report.issues.length > 0) {
            console.log(`::warning::${report.issues.length} SEO issues found`);
        }

        if (report.status === 'critical') {
            console.log(`::error::SEO Score ${report.score} below threshold ${report.threshold.critical}`);
        }

        // Generate summary for CI dashboard
        console.log('## SEO Audit Summary');
        console.log(`- **Score**: ${report.score}/100`);
        console.log(`- **Status**: ${report.status}`);
        console.log(`- **Issues**: ${report.issues.length}`);
        console.log(`- **Recommendations**: ${report.recommendations.length}`);
    }
}

// Export all integration examples
module.exports = {
    BasicIntegration,
    ReactIntegration,
    VueIntegration,
    WordPressIntegration,
    ShopifyIntegration,
    CIIntegration
};