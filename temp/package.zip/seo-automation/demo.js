#!/usr/bin/env node

/**
 * SEO Automation Suite - Demo Script
 * 
 * Demonstrates the key features of the SEO automation system
 * 
 * Author: MiniMax Agent
 * Version: 1.0.0
 */

const fs = require('fs-extra');
const path = require('path');

class SEODemo {
    constructor() {
        this.demoUrl = 'https://httpbin.org'; // A reliable test URL
        this.configPath = './demo-config.json';
    }

    async runDemo() {
        console.log('🚀 SEO Automation Suite Demo');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

        try {
            await this.setupDemoConfig();
            await this.demoBasicAnalysis();
            await this.demoTechnicalSEO();
            await this.demoContentOptimization();
            await this.demoPerformanceMonitoring();
            await this.demoReportGeneration();
            
            this.displayDemoSummary();

        } catch (error) {
            console.error('❌ Demo failed:', error.message);
        }
    }

    async setupDemoConfig() {
        console.log('📋 Setting up demo configuration...');
        
        const demoConfig = {
            website: {
                baseUrl: this.demoUrl,
                sitemapUrls: [`${this.demoUrl}/xml`],
                crawlDepth: 1,
                maxPages: 5,
                respectRobotsTxt: true,
                userAgent: 'SEO-Demo-Bot/1.0'
            },
            technicalSEO: {
                checkPageSpeed: true,
                checkCoreWebVitals: true,
                checkMetaTags: true,
                checkStructuredData: true,
                checkInternalLinks: true,
                checkImageOptimization: true,
                checkSSL: true,
                checkMobileFriendliness: true
            },
            contentOptimization: {
                targetKeywords: ['api', 'http', 'testing'],
                minTitleLength: 30,
                maxTitleLength: 60,
                minDescriptionLength: 120,
                maxDescriptionLength: 160,
                minContentLength: 300,
                checkKeywordDensity: true,
                optimizeHeadings: true
            },
            performanceMonitoring: {
                checkEveryHours: 24,
                alerts: {
                    pageSpeed: {
                        warning: 3000,
                        critical: 5000
                    },
                    coreWebVitals: {
                        lcp: 2500,
                        fid: 100,
                        cls: 0.1
                    }
                }
            },
            automation: {
                autoFix: {
                    missingAltTags: false,
                    missingTitleTags: false,
                    duplicateMetaDescriptions: false
                },
                scheduledTasks: {
                    fullAudit: "0 2 * * *",
                    contentCheck: "0 */6 * * *",
                    performanceCheck: "0 */12 * * *"
                }
            },
            reporting: {
                outputDirectory: "./demo-reports",
                formats: ["json", "html", "csv"],
                emailReports: false,
                includeRecommendations: true
            }
        };

        await fs.ensureDir(path.dirname(this.configPath));
        await fs.writeJson(this.configPath, demoConfig, { spaces: 2 });
        
        console.log('✅ Demo configuration created\n');
    }

    async demoBasicAnalysis() {
        console.log('🔍 Demo 1: Basic SEO Analysis');
        console.log('Testing comprehensive SEO audit on:', this.demoUrl);
        
        try {
            const SEOAutomationSuite = require('./lib/seo-automation');
            const seo = new SEOAutomationSuite(this.configPath);
            await seo.initialize();
            
            const results = await seo.runFullAudit({
                maxPages: 3,
                quickMode: true
            });
            
            console.log(`📊 Results:`);
            console.log(`   Overall Score: ${results.summary.score}/100`);
            console.log(`   Technical SEO: ${results.audit.technical?.score || 'N/A'}/100`);
            console.log(`   Content Score: ${results.audit.content?.score || 'N/A'}/100`);
            console.log(`   Performance: ${results.audit.performance?.score || 'N/A'}/100`);
            console.log(`   Issues Found: ${results.summary.issues.length}`);
            console.log(`   Recommendations: ${results.summary.recommendations.length}\n`);

        } catch (error) {
            console.log(`   ⚠️  Analysis failed: ${error.message}`);
            console.log('   This is expected for some test URLs\n');
        }
    }

    async demoTechnicalSEO() {
        console.log('🔧 Demo 2: Technical SEO Analysis');
        console.log('Analyzing technical aspects like meta tags, structured data...');
        
        try {
            const SEOAnalyzer = require('./lib/seo-analyzer');
            const analyzer = new SEOAnalyzer(require('./demo-config.json'));
            
            const results = await analyzer.runTechnicalAudit({
                maxPages: 2,
                quickMode: true
            });
            
            console.log(`📊 Technical Analysis:`);
            console.log(`   Score: ${results.score}/100`);
            console.log(`   Pages Analyzed: ${results.pagesAnalyzed.length}`);
            console.log(`   Key Issues:`);
            
            results.issues.slice(0, 3).forEach(issue => {
                console.log(`   - ${issue.type}: ${issue.message}`);
            });
            
            if (results.strengths.length > 0) {
                console.log(`   ✅ Strengths:`);
                results.strengths.slice(0, 2).forEach(strength => {
                    console.log(`   - ${strength}`);
                });
            }
            console.log();

        } catch (error) {
            console.log(`   ⚠️  Technical analysis failed: ${error.message}\n`);
        }
    }

    async demoContentOptimization() {
        console.log('📝 Demo 3: Content Optimization');
        console.log('Analyzing content quality, keywords, and readability...');
        
        try {
            const ContentOptimizer = require('./lib/content-optimizer');
            const optimizer = new ContentOptimizer(require('./demo-config.json'));
            
            const results = await optimizer.analyzeContent({
                maxPages: 2,
                quickMode: true
            });
            
            console.log(`📊 Content Analysis:`);
            console.log(`   Score: ${results.score}/100`);
            
            if (results.keywordAnalysis.targetKeywords) {
                console.log(`   Target Keywords Performance:`);
                Object.entries(results.keywordAnalysis.targetKeywords).forEach(([keyword, data]) => {
                    console.log(`   - "${keyword}": ${data.averageDensity}% density, ${data.pagesUsing} pages`);
                });
            }
            
            console.log(`   Top Issues:`);
            results.contentIssues.slice(0, 3).forEach(issue => {
                console.log(`   - ${issue.type}: ${issue.message} (${issue.count} pages)`);
            });
            console.log();

        } catch (error) {
            console.log(`   ⚠️  Content analysis failed: ${error.message}\n`);
        }
    }

    async demoPerformanceMonitoring() {
        console.log('⚡ Demo 4: Performance Monitoring');
        console.log('Checking page speed, Core Web Vitals, and optimization...');
        
        try {
            const PerformanceMonitor = require('./lib/performance-monitor');
            const monitor = new PerformanceMonitor(require('./demo-config.json'));
            
            const results = await monitor.checkPerformance({
                maxPages: 2,
                quickMode: true
            });
            
            console.log(`📊 Performance Analysis:`);
            console.log(`   Score: ${results.score}/100`);
            
            if (results.coreWebVitals.lcp) {
                console.log(`   Core Web Vitals:`);
                console.log(`   - LCP: ${(results.coreWebVitals.lcp.average / 1000).toFixed(2)}s`);
                console.log(`   - FID: ${results.coreWebVitals.fid.average.toFixed(0)}ms`);
                console.log(`   - CLS: ${results.coreWebVitals.cls.average.toFixed(3)}`);
            }
            
            if (results.alerts.length > 0) {
                console.log(`   🚨 Alerts:`);
                results.alerts.slice(0, 2).forEach(alert => {
                    console.log(`   - ${alert.type}: ${alert.message}`);
                });
            }
            console.log();

        } catch (error) {
            console.log(`   ⚠️  Performance analysis failed: ${error.message}\n`);
        }
    }

    async demoReportGeneration() {
        console.log('📊 Demo 5: Report Generation');
        console.log('Creating comprehensive reports...');
        
        try {
            // Create sample audit data for demo
            const sampleAudit = {
                timestamp: new Date().toISOString(),
                website: this.demoUrl,
                executionTime: 5000,
                summary: {
                    score: 75,
                    issues: [
                        {
                            type: 'missing_meta_description',
                            severity: 'medium',
                            message: 'Missing meta description on some pages',
                            count: 2
                        },
                        {
                            type: 'slow_load_time',
                            severity: 'warning',
                            message: 'Page load time exceeds recommended threshold',
                            count: 1
                        }
                    ],
                    recommendations: [
                        'Add meta descriptions to all pages',
                        'Optimize images for faster loading',
                        'Implement structured data markup',
                        'Improve internal linking structure'
                    ],
                    strengths: [
                        'Good mobile optimization',
                        'SSL certificate properly configured',
                        'Clean URL structure'
                    ]
                },
                audit: {
                    technical: {
                        score: 80,
                        issues: [],
                        recommendations: ['Add more structured data'],
                        strengths: ['Mobile-friendly design'],
                        metrics: { totalPages: 2, averageLoadTime: 2500 }
                    },
                    content: {
                        score: 70,
                        contentIssues: [],
                        recommendations: ['Increase content length'],
                        strengths: ['Good keyword usage'],
                        metrics: { averageWordCount: 500, averageReadability: 65 }
                    },
                    performance: {
                        score: 75,
                        alerts: [],
                        recommendations: ['Optimize Core Web Vitals'],
                        strengths: ['Fast server response'],
                        metrics: { pagesWithGoodLCP: 1, fastPages: 1 }
                    }
                }
            };

            const ReportGenerator = require('./lib/report-generator');
            const reporter = new ReportGenerator(require('./demo-config.json'));
            
            await reporter.generateReport(sampleAudit);
            
            console.log(`✅ Reports generated in: ./demo-reports/`);
            console.log(`   - HTML Report: demo-reports/seo-audit-*.html`);
            console.log(`   - JSON Report: demo-reports/seo-audit-*.json`);
            console.log(`   - CSV Reports: demo-reports/seo-audit-*-*.csv`);
            console.log(`   - Executive Summary: demo-reports/executive-summary-*.html\n`);

        } catch (error) {
            console.log(`   ⚠️  Report generation failed: ${error.message}\n`);
        }
    }

    displayDemoSummary() {
        console.log('🎉 Demo Complete!');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
        
        console.log('📋 What we demonstrated:');
        console.log('   ✅ Comprehensive SEO audit and scoring');
        console.log('   ✅ Technical SEO analysis (meta tags, structure)');
        console.log('   ✅ Content optimization and keyword analysis');
        console.log('   ✅ Performance monitoring and Core Web Vitals');
        console.log('   ✅ Automated report generation (HTML, JSON, CSV)');
        
        console.log('\n🚀 Next steps:');
        console.log('   1. Configure your website: Edit ./config/seo-config.json');
        console.log('   2. Run full audit: npm run seo-audit');
        console.log('   3. Start automation: npm start');
        console.log('   4. Check reports: Open ./reports/ directory');
        
        console.log('\n📚 Key Files:');
        console.log('   - Main Entry: ./index.js');
        console.log('   - Configuration: ./config/seo-config.json');
        console.log('   - Setup Script: ./scripts/setup.js');
        console.log('   - Integration Examples: ./examples/integrations.js');
        console.log('   - Documentation: ./README.md');
        
        console.log('\n🔧 Customization Options:');
        console.log('   - Modify scoring algorithms in ./lib/');
        console.log('   - Add custom checks and validations');
        console.log('   - Integrate with your CI/CD pipeline');
        console.log('   - Connect to monitoring and alert systems');
        
        console.log('\n💡 Pro Tips:');
        console.log('   - Start with a small maxPages setting (10-20)');
        console.log('   - Use quickMode for faster initial testing');
        console.log('   - Review reports in ./reports/ after each run');
        console.log('   - Set up scheduled tasks for continuous monitoring');
        
        console.log('\n✨ Happy optimizing!');
    }

    async cleanup() {
        try {
            // Clean up demo files
            await fs.remove('./demo-config.json');
            await fs.remove('./demo-reports');
            console.log('\n🧹 Demo cleanup completed');
        } catch (error) {
            console.log('⚠️  Cleanup warning:', error.message);
        }
    }
}

// Run the demo
const demo = new SEODemo();
demo.runDemo()
    .then(() => demo.cleanup())
    .catch(console.error);