#!/usr/bin/env node

/**
 * SEO Automation Suite - Setup Script
 * 
 * Initializes the SEO automation system for your website
 * 
 * Author: MiniMax Agent
 * Version: 1.0.0
 */

const fs = require('fs-extra');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

class SEOSetup {
    constructor() {
        this.configPath = './config/seo-config.json';
        this.projectPath = process.cwd();
    }

    /**
     * Start the setup process
     */
    async start() {
        console.log('🚀 Welcome to SEO Automation Suite Setup!\n');
        console.log('This setup will help you configure the SEO automation system for your website.');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

        try {
            await this.collectConfiguration();
            await this.installDependencies();
            await this.createExampleFiles();
            this.displayCompletionMessage();
        } catch (error) {
            console.error('❌ Setup failed:', error.message);
            process.exit(1);
        } finally {
            rl.close();
        }
    }

    /**
     * Collect configuration from user
     */
    async collectConfiguration() {
        console.log('📋 Configuration Setup\n');

        const config = {
            website: {},
            technicalSEO: {
                checkPageSpeed: true,
                checkCoreWebVitals: true,
                checkMetaTags: true,
                checkStructuredData: true,
                checkInternalLinks: true,
                checkImageOptimization: true,
                checkSSL: true,
                checkMobileFriendliness: true
            },
            contentOptimization: {
                targetKeywords: [],
                minTitleLength: 30,
                maxTitleLength: 60,
                minDescriptionLength: 120,
                maxDescriptionLength: 160,
                minContentLength: 300,
                checkKeywordDensity: true,
                optimizeHeadings: true
            },
            performanceMonitoring: {
                checkEveryHours: 24,
                alerts: {
                    pageSpeed: {
                        warning: 3,
                        critical: 5
                    },
                    coreWebVitals: {
                        lcp: 2.5,
                        fid: 100,
                        cls: 0.1
                    }
                }
            },
            automation: {
                autoFix: {
                    missingAltTags: true,
                    missingTitleTags: true,
                    duplicateMetaDescriptions: true
                },
                scheduledTasks: {
                    fullAudit: "0 2 * * *",
                    contentCheck: "0 */6 * * *",
                    performanceCheck: "0 */12 * * *"
                }
            },
            reporting: {
                outputDirectory: "./reports",
                formats: ["json", "html", "csv"],
                emailReports: false,
                includeRecommendations: true
            }
        };

        // Website configuration
        config.website.baseUrl = await this.askQuestion('🌐 Enter your website URL (e.g., https://example.com): ');
        config.website.sitemapUrls = [config.website.baseUrl.replace(/\/$/, '') + '/sitemap.xml'];
        config.website.crawlDepth = parseInt(await this.askQuestion('🔍 Enter crawl depth (1-5, default 3): ')) || 3;
        config.website.maxPages = parseInt(await this.askQuestion('📄 Max pages to analyze (default 100): ')) || 100;

        // Target keywords
        const keywordsInput = await this.askQuestion('🎯 Enter target keywords (comma-separated, or press Enter to skip): ');
        if (keywordsInput.trim()) {
            config.contentOptimization.targetKeywords = keywordsInput.split(',').map(k => k.trim());
        }

        // Automation preferences
        console.log('\n⚙️  Automation Preferences:\n');
        const autoFixAlt = await this.askQuestion('🤖 Auto-fix missing alt tags? (y/N): ');
        config.automation.autoFix.missingAltTags = autoFixAlt.toLowerCase() === 'y';

        const autoFixTitle = await this.askQuestion('🤖 Auto-fix missing title tags? (y/N): ');
        config.automation.autoFix.missingTitleTags = autoFixTitle.toLowerCase() === 'y';

        // Save configuration
        await fs.ensureDir(path.dirname(this.configPath));
        await fs.writeJson(this.configPath, config, { spaces: 2 });
        
        console.log('\n✅ Configuration saved successfully!\n');
    }

    /**
     * Install required dependencies
     */
    async installDependencies() {
        console.log('📦 Installing dependencies...\n');

        const { execSync } = require('child_process');

        try {
            // Check if package.json exists
            const packageExists = await fs.pathExists('./package.json');
            
            if (!packageExists) {
                console.log('📝 Creating package.json...');
                const packageData = {
                    "name": "seo-automation-project",
                    "version": "1.0.0",
                    "description": "SEO automation for your website",
                    "main": "index.js",
                    "scripts": {
                        "start": "node index.js",
                        "seo-audit": "node scripts/seo-audit.js",
                        "seo-monitor": "node scripts/seo-monitor.js"
                    }
                };
                await fs.writeJson('./package.json', packageData, { spaces: 2 });
            }

            // Install dependencies
            console.log('⬇️  Installing SEO automation dependencies...');
            execSync('npm install cheerio puppeteer node-cron fast-xml-parser sharp fs-extra winston joi csv-writer', {
                stdio: 'inherit'
            });

            console.log('✅ Dependencies installed successfully!\n');
        } catch (error) {
            throw new Error(`Failed to install dependencies: ${error.message}`);
        }
    }

    /**
     * Create example files
     */
    async createExampleFiles() {
        console.log('📄 Creating example files...\n');

        // Create main entry point
        await this.createMainFile();
        
        // Create example scripts
        await this.createAuditScript();
        await this.createMonitorScript();
        
        // Create .gitignore
        await this.createGitIgnore();
        
        // Create README
        await this.createReadme();

        console.log('✅ Example files created successfully!\n');
    }

    /**
     * Create main index.js file
     */
    async createMainFile() {
        const mainContent = `const SEOAutomationSuite = require('./seo-automation/lib/seo-automation');

// Initialize and start SEO automation
async function startSEOAutomation() {
    try {
        const seo = new SEOAutomationSuite('./config/seo-config.json');
        
        console.log('🚀 Starting SEO Automation Suite...');
        
        // Initialize the system
        await seo.initialize();
        
        // Run initial audit
        console.log('🔍 Running initial SEO audit...');
        const results = await seo.runFullAudit();
        
        console.log(\`✅ SEO audit completed! Overall score: \${results.summary.score}/100\`);
        console.log(\`📊 Reports generated in: ./reports/\`);
        
        // Start scheduled tasks
        if (process.env.NODE_ENV !== 'test') {
            seo.setupScheduledTasks();
            console.log('⏰ Scheduled tasks started');
            console.log('🔄 Press Ctrl+C to stop the automation');
            
            // Keep the process running
            process.on('SIGINT', () => {
                console.log('\\n🛑 Stopping SEO automation...');
                seo.stop();
                process.exit(0);
            });
        }
        
    } catch (error) {
        console.error('❌ SEO automation failed:', error);
        process.exit(1);
    }
}

// Start the automation
startSEOAutomation();`;

        await fs.writeFile('./index.js', mainContent);
    }

    /**
     * Create audit script
     */
    async createAuditScript() {
        const scriptsDir = './scripts';
        await fs.ensureDir(scriptsDir);

        const auditContent = `const SEOAutomationSuite = require('../seo-automation/lib/seo-automation');

async function runSEOAudit() {
    try {
        console.log('🔍 Starting SEO audit...');
        
        const seo = new SEOAutomationSuite('../config/seo-config.json');
        await seo.initialize();
        
        const results = await seo.runFullAudit();
        
        console.log(\`\\n✅ SEO Audit Results:\`);
        console.log(\`📊 Overall Score: \${results.summary.score}/100\`);
        console.log(\`🔧 Technical SEO Score: \${results.audit.technical?.score || 'N/A'}\`);
        console.log(\`📝 Content Score: \${results.audit.content?.score || 'N/A'}\`);
        console.log(\`⚡ Performance Score: \${results.audit.performance?.score || 'N/A'}\`);
        
        console.log(\`\\n📋 Issues Found: \${results.summary.issues.length}\`);
        console.log(\`💡 Recommendations: \${results.summary.recommendations.length}\`);
        console.log(\`⭐ Strengths: \${results.summary.strengths.length}\`);
        
        console.log(\`\\n📁 Reports saved to: ./reports/\`);
        
    } catch (error) {
        console.error('❌ SEO audit failed:', error);
        process.exit(1);
    }
}

runSEOAudit();`;

        await fs.writeFile(path.join(scriptsDir, 'seo-audit.js'), auditContent);
    }

    /**
     * Create monitor script
     */
    async createMonitorScript() {
        const scriptsDir = './scripts';

        const monitorContent = `const SEOAutomationSuite = require('../seo-automation/lib/seo-automation');

async function startSEOMonitoring() {
    try {
        console.log('📊 Starting SEO monitoring...');
        
        const seo = new SEOAutomationSuite('../config/seo-config.json');
        await seo.initialize();
        
        // Start scheduled tasks
        seo.setupScheduledTasks();
        
        console.log('⏰ SEO monitoring started');
        console.log('📊 Performance checks will run automatically');
        console.log('🔄 Press Ctrl+C to stop monitoring');
        
        process.on('SIGINT', () => {
            console.log('\\n🛑 Stopping SEO monitoring...');
            seo.stop();
            process.exit(0);
        });
        
    } catch (error) {
        console.error('❌ SEO monitoring failed:', error);
        process.exit(1);
    }
}

startSEOMonitoring();`;

        await fs.writeFile(path.join(scriptsDir, 'seo-monitor.js'), monitorContent);
    }

    /**
     * Create .gitignore file
     */
    async createGitIgnore() {
        const gitignoreContent = `# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Reports and logs
reports/
logs/
*.log

# Configuration files (if they contain sensitive data)
# config/seo-config.json

# Environment files
.env
.env.local
.env.production

# IDE files
.vscode/
.idea/
*.swp
*.swo

# OS files
.DS_Store
Thumbs.db

# Build files
dist/
build/`;

        await fs.writeFile('./.gitignore', gitignoreContent);
    }

    /**
     * Create README file
     */
    async createReadme() {
        const readmeContent = `# SEO Automation Suite

Automated SEO optimization and monitoring for your website.

## Features

- 🔍 **Technical SEO Analysis** - Automatic checking of meta tags, structured data, mobile optimization
- 📝 **Content Optimization** - Keyword analysis, content length optimization, readability scoring
- ⚡ **Performance Monitoring** - Page speed, Core Web Vitals, and resource optimization
- 📊 **Automated Reports** - Generate JSON, HTML, and CSV reports
- ⏰ **Scheduled Monitoring** - Set up automated checks and alerts

## Quick Start

1. **Install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

2. **Configure your website:**
   Edit \`./config/seo-config.json\` with your website details

3. **Run initial audit:**
   \`\`\`bash
   npm run seo-audit
   \`\`\`

4. **Start automation:**
   \`\`\`bash
   npm start
   \`\`\`

## Available Commands

- \`npm start\` - Start the full SEO automation suite
- \`npm run seo-audit\` - Run a one-time SEO audit
- \`npm run seo-monitor\` - Start continuous monitoring

## Configuration

Edit \`./config/seo-config.json\` to customize:

- **Website URL** and sitemap locations
- **Target keywords** for content optimization
- **Performance thresholds** and alert settings
- **Automation schedules** for periodic checks
- **Report formats** and output preferences

## Reports

Reports are generated in the \`./reports/\` directory:

- **JSON reports** - Machine-readable data for integration
- **HTML reports** - Human-readable summaries with visual charts
- **CSV reports** - Spreadsheet-compatible data for analysis

## Integration

This SEO automation suite can be integrated into any website workflow:

1. **CI/CD Integration** - Run audits as part of your deployment process
2. **Monitoring Dashboards** - Use JSON reports for custom dashboards
3. **Alert Systems** - Integrate with Slack, email, or other notification systems
4. **Content Management** - Use recommendations to guide content strategy

## Scheduled Tasks

The system runs automatic checks based on your configuration:

- **Full Audit** - Comprehensive SEO analysis (daily by default)
- **Content Check** - Content optimization review (every 6 hours by default)
- **Performance Check** - Speed and Core Web Vitals monitoring (every 12 hours by default)

## Customization

The modular architecture allows for easy customization:

- **Add new checks** in the respective analyzer modules
- **Customize scoring algorithms** based on your SEO priorities
- **Integrate with external APIs** for additional data sources
- **Create custom report formats** for specific business needs

## Support

For technical issues or questions, check the logs in \`./reports/\` directory for detailed information about any errors or warnings.

---

Generated by SEO Automation Suite - MiniMax Agent`;

        await fs.writeFile('./README.md', readmeContent);
    }

    /**
     * Display completion message
     */
    displayCompletionMessage() {
        console.log('🎉 SEO Automation Suite Setup Complete!');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
        console.log('✅ Configuration saved to: ./config/seo-config.json');
        console.log('📄 Main entry point: ./index.js');
        console.log('📊 Example scripts: ./scripts/');
        console.log('📋 Documentation: ./README.md\n');
        console.log('🚀 Next Steps:');
        console.log('   1. Edit ./config/seo-config.json with your website details');
        console.log('   2. Run: npm run seo-audit (to test the setup)');
        console.log('   3. Run: npm start (to start automation)\n');
        console.log('📊 Reports will be generated in: ./reports/\n');
        console.log('Happy optimizing! 🎯');
    }

    /**
     * Ask question and return promise
     */
    askQuestion(question) {
        return new Promise((resolve) => {
            rl.question(question, resolve);
        });
    }
}

// Run setup
const setup = new SEOSetup();
setup.start().catch(error => {
    console.error('Setup failed:', error);
    process.exit(1);
});