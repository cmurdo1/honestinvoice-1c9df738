# SEO Automation Suite

A comprehensive, automated SEO optimization and monitoring system for websites. This suite provides complete technical SEO analysis, content optimization, performance monitoring, and automated reporting to improve your website's search engine visibility and rankings.

## 🚀 Features

### Core Capabilities

- **🔍 Technical SEO Analysis** - Automated checking of meta tags, structured data, mobile optimization, internal linking
- **📝 Content Optimization** - Keyword analysis, content quality assessment, readability scoring
- **⚡ Performance Monitoring** - Page speed, Core Web Vitals (LCP, FID, CLS), resource optimization
- **📊 Automated Reporting** - JSON, HTML, and CSV reports with actionable recommendations
- **⏰ Scheduled Monitoring** - Automated periodic checks and alerts
- **🔧 Auto-Fix Capabilities** - Automatically fix common SEO issues where possible

### Advanced Features

- **Multi-format Reporting** - Export data in JSON, HTML, CSV, and XML formats
- **Framework Integration** - Easy integration with React, Vue, WordPress, Shopify
- **CI/CD Integration** - Integrate with your deployment pipeline
- **Custom Thresholds** - Configure performance and quality thresholds
- **Keyword Optimization** - Track and optimize keyword density and distribution
- **Mobile Performance** - Dedicated mobile optimization analysis

## 📋 Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Usage Examples](#usage-examples)
- [Framework Integration](#framework-integration)
- [Reports and Analysis](#reports-and-analysis)
- [API Reference](#api-reference)
- [Customization](#customization)
- [Troubleshooting](#troubleshooting)

## 🛠 Installation

### Method 1: Automated Setup

```bash
# Clone or download the seo-automation-suite
cd seo-automation-suite

# Run the automated setup
node scripts/setup.js

# Follow the interactive prompts
```

### Method 2: Manual Installation

```bash
# Install dependencies
npm install

# Copy configuration template
cp config/seo-config.example.json config/seo-config.json

# Edit configuration
nano config/seo-config.json

# Run initial audit
npm run seo-audit
```

## ⚡ Quick Start

### 1. Basic Usage

```javascript
const SEOAutomationSuite = require('./seo-automation/lib/seo-automation');

async function runSEOAudit() {
    // Initialize SEO automation
    const seo = new SEOAutomationSuite('./config/seo-config.json');
    await seo.initialize();
    
    // Run comprehensive audit
    const results = await seo.runFullAudit();
    
    console.log(`SEO Score: ${results.summary.score}/100`);
    console.log(`Issues Found: ${results.summary.issues.length}`);
    console.log(`Recommendations: ${results.summary.recommendations.length}`);
    
    // Reports are automatically generated in ./reports/
}

// Run the audit
runSEOAudit();
```

### 2. Start Automation

```bash
# Start continuous monitoring and automation
npm start

# Run single audit
npm run seo-audit

# Start monitoring only
npm run seo-monitor
```

### 3. CLI Usage

```bash
# Analyze specific website
node scripts/seo-audit.js --url https://example.com --max-pages 10

# Generate specific report formats
node scripts/report-generator.js --format html --output custom-report.html

# Quick performance check
node scripts/performance-check.js --threshold 3000
```

## ⚙️ Configuration

### Basic Configuration (`config/seo-config.json`)

```json
{
  "website": {
    "baseUrl": "https://your-website.com",
    "sitemapUrls": ["https://your-website.com/sitemap.xml"],
    "crawlDepth": 3,
    "maxPages": 100
  },
  "technicalSEO": {
    "checkPageSpeed": true,
    "checkCoreWebVitals": true,
    "checkMetaTags": true,
    "checkStructuredData": true
  },
  "contentOptimization": {
    "targetKeywords": ["your keyword", "secondary keyword"],
    "minTitleLength": 30,
    "maxTitleLength": 60,
    "minContentLength": 300
  },
  "performanceMonitoring": {
    "checkEveryHours": 24,
    "alerts": {
      "pageSpeed": { "warning": 3, "critical": 5 },
      "coreWebVitals": { "lcp": 2.5, "fid": 100, "cls": 0.1 }
    }
  }
}
```

### Advanced Configuration

#### Performance Thresholds
```json
"performanceMonitoring": {
  "alerts": {
    "pageSpeed": {
      "good": 1500,      // < 1.5s
      "warning": 3000,   // 1.5s - 3s
      "critical": 5000   // > 3s
    }
  }
}
```

#### Keyword Optimization
```json
"contentOptimization": {
  "targetKeywords": [
    {
      "keyword": "your main keyword",
      "priority": "high",
      "targetDensity": "1-3%",
      "requiredInTitle": true,
      "requiredInH1": true
    }
  ]
}
```

#### Scheduled Tasks (Cron Format)
```json
"automation": {
  "scheduledTasks": {
    "fullAudit": "0 2 * * *",      // Daily at 2 AM
    "contentCheck": "0 */6 * * *", // Every 6 hours
    "performanceCheck": "0 */12 * * *" // Every 12 hours
  }
}
```

## 💻 Usage Examples

### 1. Basic SEO Audit

```javascript
const SEOAutomationSuite = require('./seo-automation/lib/seo-automation');

async function basicAudit() {
    const seo = new SEOAutomationSuite();
    const results = await seo.runFullAudit();
    
    console.log('Overall Score:', results.summary.score);
    console.log('Technical SEO:', results.audit.technical?.score);
    console.log('Content Quality:', results.audit.content?.score);
    console.log('Performance:', results.audit.performance?.score);
    
    // Access specific issues
    const technicalIssues = results.audit.technical?.issues || [];
    const contentIssues = results.audit.content?.contentIssues || [];
    const performanceAlerts = results.audit.performance?.alerts || [];
    
    // All issues combined
    const allIssues = [...technicalIssues, ...contentIssues, ...performanceAlerts];
    console.log('Total Issues:', allIssues.length);
}

basicAudit();
```

### 2. Performance Monitoring

```javascript
async function monitorPerformance() {
    const seo = new SEOAutomationSuite();
    await seo.initialize();
    
    // Monitor specific pages
    const urls = [
        'https://example.com',
        'https://example.com/about',
        'https://example.com/products'
    ];
    
    for (const url of urls) {
        const result = await seo.monitor.checkPerformance({
            urls: [url]
        });
        
        console.log(`${url}: ${result.score}/100`);
        
        // Check for alerts
        if (result.alerts.length > 0) {
            console.log('Alerts:', result.alerts);
        }
    }
}
```

### 3. Content Analysis

```javascript
async function analyzeContent() {
    const seo = new SEOAutomationSuite();
    await seo.initialize();
    
    const results = await seo.optimizer.analyzeContent({
        targetKeywords: ['seo', 'optimization', 'digital marketing']
    });
    
    console.log('Content Score:', results.score);
    
    // Keyword analysis
    const keywordAnalysis = results.keywordAnalysis;
    console.log('Target Keywords Performance:', keywordAnalysis.targetKeywords);
    console.log('Top Keywords:', keywordAnalysis.topKeywords);
    
    // Content recommendations
    console.log('Recommendations:', results.recommendations);
}
```

### 4. Custom Automation

```javascript
class CustomSEOAutomation {
    constructor() {
        this.seo = new SEOAutomationSuite('./config/seo-config.json');
        this.lastScore = 100;
    }
    
    async startMonitoring() {
        await this.seo.initialize();
        
        // Run every hour
        setInterval(async () => {
            const results = await this.seo.runFullAudit();
            const currentScore = results.summary.score;
            
            // Alert on significant drops
            if (currentScore < this.lastScore - 10) {
                await this.sendAlert(
                    `SEO Score dropped from ${this.lastScore} to ${currentScore}`,
                    results
                );
            }
            
            this.lastScore = currentScore;
        }, 3600000); // 1 hour
    }
    
    async sendAlert(message, data) {
        // Send to Slack, email, etc.
        console.log('🚨 SEO Alert:', message);
    }
}

// Start custom monitoring
const monitor = new CustomSEOAutomation();
monitor.startMonitoring();
```

## 🔗 Framework Integration

### React/Next.js Integration

```javascript
// pages/_app.js
import { useEffect, useState } from 'react';

function MyApp({ Component, pageProps }) {
    const [seoData, setSeoData] = useState(null);
    
    useEffect(() => {
        // Fetch SEO data in production
        if (process.env.NODE_ENV === 'production') {
            fetch('/api/seo-analysis')
                .then(res => res.json())
                .then(setSeoData);
        }
    }, []);
    
    return (
        <div>
            {seoData && (
                <head>
                    <title>SEO Score: {seoData.score}/100</title>
                    <meta name="description" content={seoData.description} />
                </head>
            )}
            <Component {...pageProps} />
        </div>
    );
}

// pages/api/seo-analysis.js
import { BasicIntegration } from '../seo-automation/examples/integrations';

export default async function handler(req, res) {
    try {
        const integration = new BasicIntegration();
        const results = await integration.runAudit();
        
        res.status(200).json({
            score: results.summary.score,
            description: `SEO analysis showing ${results.summary.issues.length} issues`,
            issues: results.summary.issues,
            timestamp: results.timestamp
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}
```

### WordPress Integration

```php
<?php
// WordPress plugin integration example
class WordPressSEOAutomation {
    private $seo_integration;
    
    public function __construct() {
        $this->seo_integration = new WordPressIntegration(
            get_site_url(),
            get_option('wp_api_key')
        );
        
        // Hook into WordPress actions
        add_action('wp_footer', array($this, 'display_seo_widget'));
        add_action('admin_menu', array($this, 'add_seo_menu'));
    }
    
    public function run_seo_analysis() {
        $results = $this->seo_integration->analyzeWordPressSEO();
        
        // Store results in WordPress options
        update_option('seo_automation_last_analysis', $results);
        
        return $results;
    }
    
    public function display_seo_widget() {
        $data = get_option('seo_automation_last_analysis');
        if ($data && is_array($data)) {
            echo '<div id="seo-automation-widget" style="position: fixed; bottom: 20px; right: 20px; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">';
            echo '<strong>SEO Score: ' . $data['overall_score'] . '/100</strong>';
            echo '</div>';
        }
    }
}

// Initialize the plugin
new WordPressSEOAutomation();
?>
```

### CI/CD Integration

```yaml
# .github/workflows/seo-audit.yml
name: SEO Audit

on:
  push:
    branches: [ main ]
  schedule:
    - cron: '0 2 * * *' # Daily at 2 AM

jobs:
  seo-audit:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
    
    - name: Install dependencies
      run: npm install
      
    - name: Run SEO Audit
      run: npm run seo-audit
      
    - name: Upload SEO Reports
      uses: actions/upload-artifact@v3
      with:
        name: seo-reports
        path: reports/
        
    - name: SEO Score Check
      run: |
        SCORE=$(node -e "console.log(require('./reports/latest-report.json').summary.score)")
        if [ $SCORE -lt 70 ]; then
          echo "SEO Score $SCORE is below threshold"
          exit 1
        fi
```

## 📊 Reports and Analysis

### Report Types

#### 1. Comprehensive HTML Report
- Visual dashboard with charts and graphs
- Detailed analysis of all SEO aspects
- Executive summary with actionable insights
- Performance metrics and Core Web Vitals

#### 2. JSON Report
- Machine-readable data for integration
- Detailed technical analysis
- Structured data for custom dashboards
- API-friendly format

#### 3. CSV Reports
- Issues spreadsheet for team collaboration
- Page-by-page analysis data
- Performance metrics comparison
- Import into Excel/Google Sheets

#### 4. Executive Summary
- High-level overview for stakeholders
- Priority actions and quick wins
- ROI estimates for SEO improvements
- Progress tracking over time

### Understanding Scores

```
90-100: Excellent SEO Performance
80-89:  Good SEO Performance
70-79:  Fair SEO Performance (Room for improvement)
60-69:  Below Average (Needs attention)
0-59:   Poor SEO Performance (Critical issues)
```

### Core Metrics

#### Technical SEO (0-100)
- **Meta Tags**: Title and description optimization
- **Structured Data**: Schema markup validation
- **Mobile Optimization**: Responsive design compliance
- **Internal Linking**: Site structure and navigation
- **SSL and Security**: HTTPS implementation

#### Content Quality (0-100)
- **Word Count**: Content length optimization
- **Readability**: Flesch Reading Ease score
- **Keyword Optimization**: Density and distribution
- **Heading Structure**: H1-H6 hierarchy
- **Content Freshness**: Update frequency

#### Performance (0-100)
- **Page Load Speed**: Time to Interactive
- **Core Web Vitals**: LCP, FID, CLS metrics
- **Resource Optimization**: Image and asset efficiency
- **Mobile Performance**: Mobile-specific metrics
- **Network Efficiency**: Request optimization

## 🔧 API Reference

### Main Classes

#### SEOAutomationSuite
```javascript
const seo = new SEOAutomationSuite(configPath);

// Methods
await seo.initialize()
await seo.runFullAudit(options)
seo.setupScheduledTasks()
seo.stop()
```

#### SEOAnalyzer (Technical SEO)
```javascript
const analyzer = new SEOAnalyzer(config);
await analyzer.runTechnicalAudit(options)
// Returns: { score, issues, recommendations, metrics }
```

#### ContentOptimizer
```javascript
const optimizer = new ContentOptimizer(config);
await optimizer.analyzeContent(options)
// Returns: { score, keywordAnalysis, contentIssues, recommendations }
```

#### PerformanceMonitor
```javascript
const monitor = new PerformanceMonitor(config);
await monitor.checkPerformance(options)
// Returns: { score, coreWebVitals, alerts, recommendations }
```

### Utility Functions

#### SEOUtilities
```javascript
const utilities = require('./lib/utilities');

// Available methods
utilities.analyzeWebsiteStructure(url)
utilities.optimizeImage(inputPath, outputPath, options)
utilities.generateSitemap(urls, outputPath, baseUrl)
utilities.calculateKeywordDensity(keyword, text, options)
utilities.calculateReadabilityScore(text)
```

## 🎨 Customization

### Custom Scoring Algorithms

```javascript
// Custom technical SEO scorer
class CustomSEOAnalyzer extends SEOAnalyzer {
    calculatePageScore(issues, metrics) {
        let score = 100;
        
        // Custom weightings
        const weights = {
            critical: 30,  // Higher penalty for critical issues
            warning: 10,
            info: 2
        };
        
        issues.forEach(issue => {
            score -= weights[issue.severity] || 5;
        });
        
        // Custom bonuses
        if (metrics.hasStructuredData) score += 10;
        if (metrics.mobileOptimized) score += 15;
        
        return Math.max(0, Math.min(100, score));
    }
}
```

### Custom Report Formats

```javascript
class CustomReportGenerator extends ReportGenerator {
    generateMarkdownReport(auditResults) {
        const md = `# SEO Report - ${auditResults.website}

## Summary
- **Score**: ${auditResults.summary.score}/100
- **Issues**: ${auditResults.summary.issues.length}
- **Recommendations**: ${auditResults.summary.recommendations.length}

## Detailed Analysis
${auditResults.audit.technical?.issues.map(issue => 
    `- ${issue.type}: ${issue.message}`
).join('\n')}

## Next Steps
${auditResults.summary.recommendations.map(rec => 
    `- ${rec}`
).join('\n')}
`;
        
        return md;
    }
}
```

### Custom Alert System

```javascript
class CustomAlertSystem {
    async sendSlackAlert(alert) {
        const webhook = process.env.SLACK_WEBHOOK_URL;
        const message = {
            text: `🚨 SEO Alert: ${alert.type}`,
            attachments: [{
                color: this.getAlertColor(alert.severity),
                fields: [
                    { title: 'Website', value: alert.website, short: true },
                    { title: 'Score', value: alert.score.toString(), short: true },
                    { title: 'Issue', value: alert.message, short: false }
                ]
            }]
        };
        
        await fetch(webhook, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(message)
        });
    }
    
    getAlertColor(severity) {
        const colors = {
            critical: 'danger',
            warning: 'warning',
            info: 'good'
        };
        return colors[severity] || '#cccccc';
    }
}
```

## 🐛 Troubleshooting

### Common Issues

#### 1. Installation Problems

**Problem**: `Cannot find module 'puppeteer'`
```bash
# Solution
npm install --save-dev puppeteer
# or use puppeteer-core for minimal installation
npm install --save-dev puppeteer-core
```

**Problem**: `EACCES permission denied`
```bash
# Solution
sudo npm install -g puppeteer
# or fix npm permissions
npm config set prefix ~/.npm-global
export PATH=~/.npm-global/bin:$PATH
```

#### 2. Configuration Issues

**Problem**: Configuration file not found
```bash
# Solution
cp config/seo-config.example.json config/seo-config.json
# or run setup
node scripts/setup.js
```

**Problem**: Invalid website URL
```json
{
  "website": {
    "baseUrl": "https://your-website.com",  // Must include https://
    "sitemapUrls": [
      "https://your-website.com/sitemap.xml"  // Must be accessible
    ]
  }
}
```

#### 3. Performance Issues

**Problem**: Analysis takes too long
```javascript
// Solution: Reduce scope
const results = await seo.runFullAudit({
    maxPages: 10,           // Limit pages
    crawlDepth: 1,          // Reduce depth
    quickMode: true         // Skip some checks
});
```

**Problem**: Memory usage too high
```javascript
// Solution: Process in batches
const pages = await seo.analyzer.discoverPages({ maxPages: 50 });
for (let i = 0; i < pages.length; i += 10) {
    const batch = pages.slice(i, i + 10);
    await seo.analyzer.analyzeBatch(batch);
}
```

#### 4. Report Generation Issues

**Problem**: Reports not generating
```bash
# Check directory permissions
mkdir -p reports
chmod 755 reports

# Check disk space
df -h

# Verify configuration
node -e "console.log(require('./config/seo-config.json'))"
```

### Debug Mode

Enable debug logging:
```javascript
const seo = new SEOAutomationSuite('./config/seo-config.json');

// Enable debug logging
process.env.DEBUG = 'seo:*';
await seo.initialize();

// Check logs
tail -f reports/combined.log
```

### Support

For additional support:

1. **Check Logs**: Review logs in `reports/` directory
2. **Test Configuration**: Run `node scripts/setup.js --test-config`
3. **Validate URLs**: Ensure all URLs in config are accessible
4. **Check Dependencies**: Verify all npm packages are installed
5. **Review Documentation**: Check framework-specific integration guides

## 📝 Contributing

This SEO automation suite is designed to be extensible. To contribute:

1. **Add New Checks**: Extend the analyzer classes
2. **Custom Reports**: Create new report generators
3. **Integrations**: Add framework-specific examples
4. **Performance**: Optimize for larger websites
5. **Features**: Suggest new automation capabilities

## 📄 License

MIT License - feel free to use in your projects.

---

**Generated by SEO Automation Suite - MiniMax Agent**

For questions or support, please refer to the troubleshooting section or check the example integrations.